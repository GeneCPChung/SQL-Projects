INSERT INTO Employees(first_name, last_name, age) VALUES
('Dora', 'Smith', 58);
